import { Request, Response, NextFunction } from 'express';
import { stripe } from '../../config/stripe';

export const createPaymentIntent = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { amount } = req.body;

    // Create a PaymentIntent with the order amount and currency
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // Stripe expects cents (e.g., $10 = 1000)
      currency: 'inr', // or 'usd'
      automatic_payment_methods: { enabled: true },
    });

    res.status(200).json({
      clientSecret: paymentIntent.client_secret,
    });
  } catch (error) {
    next(error);
  }
};