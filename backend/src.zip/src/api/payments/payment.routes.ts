import { Router } from 'express';
import express from 'express';
import * as PaymentController from './payment.controller';
import * as WebhookController from './webhook.controller';

const router = Router();

// Standard JSON routes
router.post('/create-intent', PaymentController.createPaymentIntent);

// 🔒 Webhook Route (MUST use raw body parser for security)
router.post(
  '/webhook',
  express.raw({ type: 'application/json' }),
  WebhookController.handleStripeWebhook
);

export default router;