import { Router } from 'express';
import * as UserController from './users.controller';
import { requireAuth } from '../../middleware/auth.middleware';

const router = Router();

router.use(requireAuth); // Protect all routes

router.get('/me', UserController.getMyProfile);
router.patch('/me', UserController.updateProfile);

router.post('/addresses', UserController.addAddress);
router.delete('/addresses/:id', UserController.deleteAddress);

export default router;