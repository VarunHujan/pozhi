import { Router } from 'express';
import * as CartController from './cart.controller';
import { requireAuth } from '../../middleware/auth.middleware';

const router = Router();

// All cart routes require login
router.use(requireAuth);

router.get('/', CartController.getCart);           // View Cart
router.post('/', CartController.addToCart);        // Add Item
router.delete('/:id', CartController.removeFromCart); // Remove Item

export default router;