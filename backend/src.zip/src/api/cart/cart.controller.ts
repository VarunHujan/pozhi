import { Request, Response, NextFunction } from 'express';
import { cartService } from '../../services/cart.service';
import { addToCartSchema, updateCartItemSchema } from './cart.validation';
import { ApiError } from '../../utils/ApiError';

export const getCart = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const cart = await cartService.getCart(req.user!.id);
    res.status(200).json(cart);
  } catch (error) {
    next(error);
  }
};

export const addToCart = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const validation = addToCartSchema.safeParse(req.body);
    if (!validation.success) throw new ApiError(400, validation.error.errors[0].message);

    const item = await cartService.addToCart(req.user!.id, validation.data);
    res.status(201).json(item);
  } catch (error) {
    next(error);
  }
};

export const removeFromCart = async (req: Request, res: Response, next: NextFunction) => {
  try {
    await cartService.removeFromCart(req.user!.id, req.params.id);
    res.status(200).json({ message: 'Item removed' });
  } catch (error) {
    next(error);
  }
};