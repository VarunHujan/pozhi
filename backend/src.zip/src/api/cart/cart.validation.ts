import { z } from 'zod';

export const addToCartSchema = z.object({
  // Item must be ONE of these types
  item_type: z.enum(['gallery', 'custom']),
  
  // IDs (One is required based on type)
  frame_id: z.string().uuid(),
  gallery_art_id: z.string().uuid().optional(),
  user_upload_id: z.string().uuid().optional(),
  
  // Customization
  frame_size: z.string().min(1),
  mat_color: z.string().optional(),
  glass_type: z.string().optional(),
  
  quantity: z.number().int().min(1).max(50).default(1)
}).refine(data => {
  if (data.item_type === 'gallery' && !data.gallery_art_id) return false;
  if (data.item_type === 'custom' && !data.user_upload_id) return false;
  return true;
}, {
  message: "gallery_art_id is required for gallery items, user_upload_id for custom items"
});

export const updateCartItemSchema = z.object({
  quantity: z.number().int().min(1).max(50)
});