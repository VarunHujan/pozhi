import { Router } from 'express';
import * as UploadController from './upload.controller';
import { uploadMiddleware } from '../../middleware/upload.middleware';
import { requireAuth } from '../../middleware/auth.middleware';

const router = Router();

// POST /api/v1/upload
// 1. Check Auth (Must be logged in)
// 2. Check File (Must be image < 10MB)
// 3. Handle Controller
router.post(
  '/', 
  requireAuth, 
  uploadMiddleware.single('file'), 
  UploadController.uploadUserFile
);

export default router;