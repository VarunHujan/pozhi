import { Request, Response, NextFunction } from 'express';
import { uploadService } from '../../services/upload.service';
import { ApiError } from '../../utils/ApiError';

export const uploadUserFile = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // 1. Check if file exists
    if (!req.file) {
      throw new ApiError(400, 'No file uploaded');
    }

    // 2. Check User
    const userId = req.user?.id;
    if (!userId) {
      throw new ApiError(401, 'Unauthorized');
    }

    // 3. Process Upload
    // The service now handles S3 upload, R2 upload, AND Database insertion
    const data = await uploadService.uploadPhoto(req.file, userId);

    // 4. Return Success
    res.status(201).json({
      success: true,
      message: 'File uploaded and secured successfully',
      data: data
    });

  } catch (error) {
    next(error);
  }
};